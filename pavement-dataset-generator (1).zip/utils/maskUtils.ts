/**
 * Utility functions for pixel-level mask manipulation.
 * Operations assume RGBA data where R=G=B (grayscale/binary).
 */

export const getIndex = (x: number, y: number, width: number) => (y * width + x) * 4;

export const cloneImageData = (imageData: ImageData): ImageData => {
  return new ImageData(
    new Uint8ClampedArray(imageData.data),
    imageData.width,
    imageData.height
  );
};

export const applyThreshold = (imageData: ImageData, min: number, max: number): ImageData => {
  const data = imageData.data;
  const output = new ImageData(imageData.width, imageData.height);
  const outData = output.data;

  for (let i = 0; i < data.length; i += 4) {
    // Use Red channel as intensity
    const intensity = data[i];
    const val = (intensity >= min && intensity <= max) ? 255 : 0;
    outData[i] = val;
    outData[i + 1] = val;
    outData[i + 2] = val;
    outData[i + 3] = 255; // Full alpha
  }
  return output;
};

export const invertMask = (imageData: ImageData): ImageData => {
  const data = imageData.data;
  const output = new ImageData(imageData.width, imageData.height);
  const outData = output.data;

  for (let i = 0; i < data.length; i += 4) {
    // If it's white (crack), make it black. If black (bg), make white.
    // Assuming binary-ish input, but works on gray too.
    const val = 255 - data[i];
    outData[i] = val;
    outData[i + 1] = val;
    outData[i + 2] = val;
    outData[i + 3] = 255;
  }
  return output;
};

/**
 * Morphological operation (Erosion/Dilation) with variable kernel size
 */
export const applyMorphology = (imageData: ImageData, type: 'erode' | 'dilate', kernelSize: number = 3, iterations: number = 1): ImageData => {
  let current = imageData;
  const width = imageData.width;
  const height = imageData.height;
  const radius = Math.floor(kernelSize / 2);

  for (let it = 0; it < iterations; it++) {
    const src = current.data;
    const next = new ImageData(width, height);
    const dest = next.data;

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        let extremeVal = type === 'erode' ? 255 : 0;
        
        // Dynamic Kernel loop based on radius
        for (let ky = -radius; ky <= radius; ky++) {
          for (let kx = -radius; kx <= radius; kx++) {
            const ny = y + ky;
            const nx = x + kx;
            
            if (ny >= 0 && ny < height && nx >= 0 && nx < width) {
              const idx = (ny * width + nx) * 4;
              const val = src[idx];
              if (type === 'erode') {
                if (val < extremeVal) extremeVal = val;
              } else {
                if (val > extremeVal) extremeVal = val;
              }
            }
          }
        }
        
        const idx = (y * width + x) * 4;
        dest[idx] = extremeVal;
        dest[idx + 1] = extremeVal;
        dest[idx + 2] = extremeVal;
        dest[idx + 3] = 255;
      }
    }
    current = next;
  }
  return current;
};

export const applyOpening = (imageData: ImageData, kernelSize: number = 3, iterations: number = 1) => {
  const eroded = applyMorphology(imageData, 'erode', kernelSize, iterations);
  return applyMorphology(eroded, 'dilate', kernelSize, iterations);
};

export const applyClosing = (imageData: ImageData, kernelSize: number = 3, iterations: number = 1) => {
  const dilated = applyMorphology(imageData, 'dilate', kernelSize, iterations);
  return applyMorphology(dilated, 'erode', kernelSize, iterations);
};