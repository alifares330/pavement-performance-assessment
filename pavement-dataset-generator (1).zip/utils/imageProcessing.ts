import { AlignmentTransform } from '../types';

export const TARGET_WIDTH = 704;
export const TARGET_HEIGHT = 768;

/**
 * Loads an image from a base64 string
 */
const loadImage = (src: string): Promise<HTMLImageElement> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
};

/**
 * Processes the raw composite image from Imagen.
 * Splits it, resizes/pads to 704x768.
 * Returns both a binarized mask and a grayscale raw mask (for advanced editing).
 */
export const processCompositeImage = async (
  base64Composite: string,
  transform: AlignmentTransform = { x: 0, y: 0, scale: 1, rotation: 0 }
): Promise<{ pavement: string; mask: string; maskGrayscale: string; flags: string[] }> => {
  const img = await loadImage(base64Composite);
  
  // Create canvas for processing
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  if (!ctx) throw new Error("Could not get canvas context");

  // The composite is side-by-side. 
  // We assume 50% split.
  const sourceHalfWidth = Math.floor(img.width / 2);
  const sourceHeight = img.height;

  // Setup target canvas size
  canvas.width = TARGET_WIDTH;
  canvas.height = TARGET_HEIGHT;

  // --- 1. Process Pavement (Left Half) ---
  const scaleRatio = Math.min(TARGET_WIDTH / sourceHalfWidth, TARGET_HEIGHT / sourceHeight);
  const drawnWidth = sourceHalfWidth * scaleRatio;
  const drawnHeight = sourceHeight * scaleRatio;
  
  // Center coordinates
  const startX = (TARGET_WIDTH - drawnWidth) / 2;
  const startY = (TARGET_HEIGHT - drawnHeight) / 2;

  // Fill background black
  ctx.fillStyle = "#000000";
  ctx.fillRect(0, 0, TARGET_WIDTH, TARGET_HEIGHT);

  // Draw Left Half (Pavement)
  ctx.drawImage(
    img, 
    0, 0, sourceHalfWidth, sourceHeight, 
    startX, startY, drawnWidth, drawnHeight
  );

  const pavementDataUrl = canvas.toDataURL('image/png');

  // --- 2. Process Mask (Right Half) ---
  // Clear and fill black
  ctx.fillStyle = "#000000";
  ctx.fillRect(0, 0, TARGET_WIDTH, TARGET_HEIGHT);

  ctx.save();
  
  // Transforms
  const centerX = TARGET_WIDTH / 2;
  const centerY = TARGET_HEIGHT / 2;
  ctx.translate(centerX, centerY);

  ctx.translate(transform.x, transform.y);
  ctx.rotate((transform.rotation * Math.PI) / 180);
  ctx.scale(transform.scale, transform.scale);

  ctx.drawImage(
    img, 
    sourceHalfWidth, 0, sourceHalfWidth, sourceHeight, 
    -drawnWidth / 2, -drawnHeight / 2, drawnWidth, drawnHeight 
  );

  ctx.restore();

  // Capture the Raw Grayscale (before we manually threshold it for display, though it's already an image)
  // This preserves anti-aliased edges if they exist, useful for variable thresholding later.
  const maskGrayscaleDataUrl = canvas.toDataURL('image/png');

  // --- 3. Binarization & QC ---
  const imageData = ctx.getImageData(0, 0, TARGET_WIDTH, TARGET_HEIGHT);
  const data = imageData.data;
  let whitePixels = 0;
  let totalPixels = data.length / 4;
  const flags: string[] = [];
  const uniqueIntensities = new Set<number>();

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    
    // Grayscale approximation
    const brightness = (r + g + b) / 3;
    uniqueIntensities.add(Math.floor(brightness));

    // Hard Threshold for the default 'mask' output
    // The user can override this in the editor using the grayscale version
    if (brightness > 127) {
      data[i] = 255;
      data[i+1] = 255;
      data[i+2] = 255;
      whitePixels++;
    } else {
      data[i] = 0;
      data[i+1] = 0;
      data[i+2] = 0;
    }
    data[i+3] = 255;
  }

  // QC Checks
  if (whitePixels / totalPixels > 0.5) flags.push('inverted_mask_suspected');
  if (whitePixels === 0) flags.push('empty_mask');

  ctx.putImageData(imageData, 0, 0);
  const maskDataUrl = canvas.toDataURL('image/png');

  return {
    pavement: pavementDataUrl,
    mask: maskDataUrl, // Binarized default
    maskGrayscale: maskGrayscaleDataUrl, // Raw aligned grayscale
    flags
  };
};