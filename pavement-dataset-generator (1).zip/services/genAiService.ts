import { GoogleGenAI, Type } from "@google/genai";
import { GenerationParams } from "../types";

// Helper to pick random item from array
const sample = <T>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

// Helper to join multiple selections naturally
const joinNatural = (arr: string[]) => {
  if (arr.length === 0) return "";
  if (arr.length === 1) return arr[0];
  return arr.slice(0, -1).join(", ") + " and " + arr[arr.length - 1];
};

/**
 * Validates if a raw prompt is relevant for generating split image pavement crack datasets.
 */
export const validatePavementPrompt = async (prompt: string, apiKey: string): Promise<{ valid: boolean; message: string }> => {
  if (!apiKey) throw new Error("API Key missing");
  const ai = new GoogleGenAI({ apiKey });

  const systemInstruction = `
    You are a strict validator for a specialized dataset generation tool.
    The tool generates "Split Images" containing:
    1. A top-down view of pavement/road surface with cracks.
    2. A binary segmentation mask of those cracks.

    Analyze the user's prompt.
    Return JSON: { "valid": boolean, "message": string }
    
    Rules:
    - valid: true ONLY if the prompt describes generating pavement cracks, road surface defects, or specifically mentions the split image/mask structure for this domain.
    - valid: false if the prompt is about unrelated topics (e.g., "draw a cat", "landscape", "portrait") or violates safety policies.
    - message: A short explanation of why it passed or failed. If failed, suggest how to make it relevant to pavement crack segmentation.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-latest',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            valid: { type: Type.BOOLEAN },
            message: { type: Type.STRING }
          },
          required: ["valid", "message"]
        }
      }
    });

    const result = JSON.parse(response.text || '{}');
    return {
      valid: !!result.valid,
      message: result.message || "Validation failed"
    };
  } catch (error) {
    console.error("Validation error", error);
    // Fallback if validation fails (e.g. strict safety filters)
    return { valid: false, message: "Could not validate prompt. Please try again or refine the text." };
  }
};

export const generateSample = async (params: GenerationParams, apiKey: string) => {
  if (!apiKey) throw new Error("API Key is missing. Please provide a valid Gemini API Key in the settings.");
  
  const ai = new GoogleGenAI({ apiKey: apiKey });
  const startTime = Date.now();

  let promptText = "";
  let usedParamsObj: any = {};

  if (params.promptMode === 'raw') {
    // --- RAW MODE ---
    promptText = params.rawPrompt;
    usedParamsObj = { mode: 'raw', custom: params.rawPrompt };
  } else {
    // --- BUILDER MODE ---
    // 1. Construct Random Prompt based on constraints
    const selectedMaterial = params.material || 'asphalt';
    const selectedMorphology = params.morphology.length ? sample(params.morphology) : 'mapped/alligator';
    const selectedOrientation = params.orientation.length ? sample(params.orientation) : 'complex';
    const selectedLighting = params.lighting.length ? sample(params.lighting) : 'uniform overhead';
    const selectedTexture = params.texture.length ? sample(params.texture) : 'rough';
    
    // Random subset of environment features
    const envCount = Math.floor(Math.random() * (params.environment.length + 1));
    const shuffledEnv = [...params.environment].sort(() => 0.5 - Math.random());
    const selectedEnv = shuffledEnv.slice(0, Math.min(envCount, 2));

    // Random subset of distress features
    const distressCount = Math.floor(Math.random() * (params.distresses.length + 1));
    const shuffledDistress = [...params.distresses].sort(() => 0.5 - Math.random());
    const selectedDistress = shuffledDistress.slice(0, Math.min(distressCount, 2));

    const envDescription = selectedEnv.length > 0 
      ? `featuring ${joinNatural(selectedEnv)}` 
      : "";
    
    const distressDescription = selectedDistress.length > 0
      ? `with visible ${joinNatural(selectedDistress)}`
      : "";

    promptText = `
      A single high-resolution image divided into two equal vertical halves.
      Left half: top-down (nadir) aerial view of worn ${selectedMaterial} pavement with ${selectedTexture} texture, ${selectedLighting} lighting. 
      The scene includes ${envDescription} ${envDescription && distressDescription ? 'and' : ''} ${distressDescription}.
      A ${selectedMorphology} crack formation runs across the surface in a ${selectedOrientation} orientation.
      Right half: binary crack mask displaying ONLY the cracks from the left half as sharp white lines on a pure black background.
      The mask must be pixel-perfectly aligned and exactly the same size as the left half.
      ${params.customPrompt ? `Additional details: ${params.customPrompt}` : ''}
    `.trim();

    usedParamsObj = {
      model: params.model,
      material: selectedMaterial,
      morphology: selectedMorphology,
      orientation: selectedOrientation,
      lighting: selectedLighting,
      texture: selectedTexture,
      environment: selectedEnv.join(', '),
      distresses: selectedDistress.join(', ')
    };
  }

  // 2. Select Model and Call API
  
  if (params.model === 'gemini-flash' || params.model === 'gemini-pro-image') {
    // --- Gemini Models (Flash Image & Pro Image) ---
    const modelName = params.model === 'gemini-flash' 
      ? 'gemini-2.5-flash-image' 
      : 'gemini-3-pro-image-preview';

    try {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: { parts: [{ text: promptText }] },
        config: {
          temperature: params.temperature,
          seed: params.useRandomSeed ? Math.floor(Math.random() * 2147483647) : params.seedValue,
          imageConfig: {
             aspectRatio: "16:9"
             // imageSize is supported by pro, but 1K (default) is sufficient for our 704px target
          }
        }
      });
      const endTime = Date.now();
      const executionTimeMs = endTime - startTime;

      // Extract image from parts (it might not be the first part)
      let fullDataUrl = null;
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData && part.inlineData.data) {
             fullDataUrl = `data:image/png;base64,${part.inlineData.data}`;
             break;
          }
        }
      }

      if (!fullDataUrl) {
         // Fallback check for text if image generation failed or was refused
         const text = response.text;
         if (text) throw new Error(`Model returned text instead of image: ${text.substring(0, 100)}...`);
         throw new Error("No image data found in Gemini response");
      }

      const usage = response.usageMetadata;

      return {
        image: fullDataUrl,
        prompt: promptText,
        usedParams: usedParamsObj,
        executionTimeMs,
        tokenUsage: usage ? {
            promptTokens: usage.promptTokenCount || 0,
            responseTokens: usage.candidatesTokenCount || 0,
            totalTokens: usage.totalTokenCount || 0
        } : undefined
      };
    } catch (e) {
      console.error(`${modelName} generation failed`, e);
      throw e;
    }

  } else {
    // --- Imagen 4 Logic (Default) ---
    // Model: imagen-4.0-ultra-generate-001
    try {
      const response = await ai.models.generateImages({
        model: 'imagen-4.0-ultra-generate-001',
        prompt: promptText,
        config: {
          numberOfImages: 1,
          aspectRatio: "16:9",
          outputMimeType: "image/png",
          // Note: Imagen might not support temperature, but we pass seed if supported.
          // @ts-ignore - passing seed just in case it's supported by the underlying API
          seed: params.useRandomSeed ? Math.floor(Math.random() * 2147483647) : params.seedValue
        }
      });
      const endTime = Date.now();
      const executionTimeMs = endTime - startTime;

      const generatedImage = response.generatedImages?.[0]?.image;
      
      if (!generatedImage || !generatedImage.imageBytes) {
        throw new Error("No image generated by Imagen");
      }

      const fullDataUrl = `data:image/png;base64,${generatedImage.imageBytes}`;

      return {
        image: fullDataUrl,
        prompt: promptText,
        usedParams: usedParamsObj,
        executionTimeMs,
        tokenUsage: undefined // Imagen responses via SDK don't standardly return token usage currently
      };
    } catch (e) {
      console.error("Imagen generation failed", e);
      throw e;
    }
  }
};