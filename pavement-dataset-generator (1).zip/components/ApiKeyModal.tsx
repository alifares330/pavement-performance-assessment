import React, { useState, useEffect } from 'react';
import { Key, Lock, Eye, EyeOff, ExternalLink, X, Check, AlertCircle, ArrowRight } from 'lucide-react';

interface ApiKeyModalProps {
  isOpen: boolean;
  onSave: (key: string) => void;
  onClose: () => void;
  initialKey?: string;
  forced?: boolean;
}

export const ApiKeyModal: React.FC<ApiKeyModalProps> = ({ 
  isOpen, 
  onSave, 
  onClose, 
  initialKey = '', 
  forced = false 
}) => {
  const [key, setKey] = useState(initialKey);
  const [showKey, setShowKey] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    setKey(initialKey);
    setError('');
  }, [initialKey, isOpen]);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    const trimmed = key.trim();
    if (!trimmed) {
      setError('API key is required');
      return;
    }
    // Basic format check (optional, but good for feedback)
    if (!trimmed.startsWith('AIza')) {
       // We can allow it but maybe show a warning, or strict enforce. 
       // For now, we'll allow it but usually Google keys start with AIza.
    }
    onSave(trimmed);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm transition-all duration-300">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-100 dark:bg-indigo-900 rounded-lg">
              <Key className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            </div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">API Key Configuration</h2>
          </div>
          {!forced && (
            <button 
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Body */}
        <div className="p-6 space-y-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider">
                Google Gemini API Key
              </label>
              <div className="relative group">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors">
                  <Lock className="w-5 h-5" />
                </div>
                <input
                  type={showKey ? "text" : "password"}
                  value={key}
                  onChange={(e) => {
                    setKey(e.target.value);
                    if (error) setError('');
                  }}
                  className={`w-full pl-10 pr-12 py-3 bg-white dark:bg-slate-950 border rounded-xl outline-none text-sm font-medium text-slate-900 dark:text-white placeholder-slate-400 transition-all
                    ${error 
                      ? 'border-red-300 focus:border-red-500 focus:ring-4 focus:ring-red-500/10' 
                      : 'border-slate-300 dark:border-slate-700 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10'
                    }`}
                  placeholder="AIzaSy..."
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => setShowKey(!showKey)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {error ? (
                <div className="flex items-center gap-1.5 text-xs text-red-500 font-medium animate-in slide-in-from-left-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  {error}
                </div>
              ) : (
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Your key is stored locally in your browser and never sent to our servers.
                </p>
              )}
            </div>

            {/* Info Box */}
            <div className="flex gap-3 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-900/30">
              <div className="shrink-0 mt-0.5">
                 <ExternalLink className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              </div>
              <div className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                Don't have a key?{' '}
                <a 
                  href="https://aistudio.google.com/app/apikey" 
                  target="_blank" 
                  rel="noreferrer"
                  className="font-semibold text-blue-600 dark:text-blue-400 hover:underline hover:text-blue-700 dark:hover:text-blue-300 transition-colors"
                >
                  Get one for free from Google AI Studio
                </a>
                .
              </div>
            </div>
          </form>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-700 flex items-center justify-end gap-3">
          {!forced && (
            <button
              onClick={onClose}
              className="px-4 py-2.5 text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-700 focus:ring-4 focus:ring-slate-200 dark:focus:ring-slate-800 transition-all"
            >
              Cancel
            </button>
          )}
          <button
            onClick={() => handleSubmit()}
            disabled={!key.trim()}
            className="flex items-center gap-2 px-6 py-2.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 rounded-xl shadow-lg shadow-indigo-500/30 disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none focus:ring-4 focus:ring-indigo-500/20 transition-all transform active:scale-[0.98]"
          >
            {key.trim() ? <Check className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
            Save API Key
          </button>
        </div>
      </div>
    </div>
  );
};