import React, { useState } from 'react';
import { GenerationParams, CrackMorphology, CrackOrientation, LightingCondition, EnvironmentFeature, SurfaceTexture, AIModel, OtherDistress } from '../types';
import { Play, Download, Settings2, Square, ChevronDown, ChevronUp, Sliders, Type, AlertCircle } from 'lucide-react';

interface Props {
  params: GenerationParams;
  setParams: (p: GenerationParams) => void;
  onGenerate: () => void;
  onStop: () => void;
  isGenerating: boolean;
  progress: string;
}

const CollapsibleSection = ({ title, children, defaultOpen = false }: { title: string, children?: React.ReactNode, defaultOpen?: boolean }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-slate-100 dark:border-slate-800 last:border-0 py-2">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-lg px-2 -ml-2 transition-colors"
      >
        <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">{title}</h4>
        {isOpen ? <ChevronUp size={14} className="text-slate-400" /> : <ChevronDown size={14} className="text-slate-400" />}
      </button>
      {isOpen && <div className="pt-2 pb-2 pl-1">{children}</div>}
    </div>
  );
};

const CheckboxList = ({ options, selected, onChange }: { options: string[], selected: string[], onChange: (val: string[]) => void }) => (
  <div className="space-y-1.5">
    {options.map((opt: string) => (
      <label key={opt} className="flex items-center text-sm text-slate-700 dark:text-slate-300 hover:text-indigo-900 dark:hover:text-indigo-400 cursor-pointer">
        <input
          type="checkbox"
          checked={selected.includes(opt)}
          onChange={(e) => {
            if (e.target.checked) onChange([...selected, opt]);
            else onChange(selected.filter((x: string) => x !== opt));
          }}
          className="w-4 h-4 rounded border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500 bg-white dark:bg-slate-800 mr-2"
        />
        <span className="capitalize">{opt}</span>
      </label>
    ))}
  </div>
);

const RadioList = ({ options, selected, onChange }: { options: string[], selected: string, onChange: (val: any) => void }) => (
  <div className="space-y-1.5">
    {options.map((opt: string) => (
      <label key={opt} className="flex items-center text-sm text-slate-700 dark:text-slate-300 hover:text-indigo-900 dark:hover:text-indigo-400 cursor-pointer">
        <input
          type="radio"
          checked={selected === opt}
          onChange={() => onChange(opt)}
          className="w-4 h-4 border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500 bg-white dark:bg-slate-800 mr-2"
        />
        <span className="capitalize">{opt}</span>
      </label>
    ))}
  </div>
);

const ModelSelector = ({ selected, onChange }: { selected: AIModel, onChange: (m: AIModel) => void }) => (
  <div className="mb-6 bg-slate-50 dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700 transition-colors">
    <div className="flex items-center gap-2 mb-2">
      <Settings2 className="w-4 h-4 text-slate-500 dark:text-slate-400" />
      <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Generative Model</h4>
    </div>
    <div className="grid grid-cols-1 gap-2">
       <button 
         onClick={() => onChange('imagen-4')}
         className={`relative flex items-center p-2 rounded-lg border text-left transition-all ${selected === 'imagen-4' ? 'bg-white dark:bg-slate-700 border-indigo-600 dark:border-indigo-500 shadow-sm ring-1 ring-indigo-600 dark:ring-indigo-500' : 'bg-white dark:bg-slate-700/50 border-slate-200 dark:border-slate-600 hover:border-slate-300 dark:hover:border-slate-500'}`}
       >
         <div className={`w-3 h-3 rounded-full border mr-3 ${selected === 'imagen-4' ? 'border-4 border-indigo-600 dark:border-indigo-500' : 'border-slate-300 dark:border-slate-500'}`}></div>
         <div>
           <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">Imagen 4 Ultra</div>
           <div className="text-[10px] text-slate-500 dark:text-slate-400">High fidelity, strict adherence</div>
         </div>
       </button>

       <button 
         onClick={() => onChange('gemini-pro-image')}
         className={`relative flex items-center p-2 rounded-lg border text-left transition-all ${selected === 'gemini-pro-image' ? 'bg-white dark:bg-slate-700 border-indigo-600 dark:border-indigo-500 shadow-sm ring-1 ring-indigo-600 dark:ring-indigo-500' : 'bg-white dark:bg-slate-700/50 border-slate-200 dark:border-slate-600 hover:border-slate-300 dark:hover:border-slate-500'}`}
       >
         <div className={`w-3 h-3 rounded-full border mr-3 ${selected === 'gemini-pro-image' ? 'border-4 border-indigo-600 dark:border-indigo-500' : 'border-slate-300 dark:border-slate-500'}`}></div>
         <div>
           <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">Gemini 3 Pro</div>
           <div className="text-[10px] text-slate-500 dark:text-slate-400">Enhanced reasoning & visual quality</div>
         </div>
       </button>

       <button 
         onClick={() => onChange('gemini-flash')}
         className={`relative flex items-center p-2 rounded-lg border text-left transition-all ${selected === 'gemini-flash' ? 'bg-white dark:bg-slate-700 border-indigo-600 dark:border-indigo-500 shadow-sm ring-1 ring-indigo-600 dark:ring-indigo-500' : 'bg-white dark:bg-slate-700/50 border-slate-200 dark:border-slate-600 hover:border-slate-300 dark:hover:border-slate-500'}`}
       >
         <div className={`w-3 h-3 rounded-full border mr-3 ${selected === 'gemini-flash' ? 'border-4 border-indigo-600 dark:border-indigo-500' : 'border-slate-300 dark:border-slate-500'}`}></div>
         <div>
           <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">Gemini 2.5 Flash</div>
           <div className="text-[10px] text-slate-500 dark:text-slate-400">Fast, efficient generation</div>
         </div>
       </button>
    </div>
  </div>
);

export const ControlPanel: React.FC<Props> = ({ params, setParams, onGenerate, onStop, isGenerating, progress }) => {
  return (
    <div className="w-80 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 h-screen overflow-y-auto flex flex-col shadow-xl z-20 transition-colors duration-200">
      <div className="p-6 border-b border-slate-100 dark:border-slate-800">
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">Pavement AI</h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Synthetic Crack Dataset Generator</p>
      </div>

      <div className="p-6 flex-1 space-y-2">
        <ModelSelector selected={params.model} onChange={(m) => setParams({ ...params, model: m })} />

        <div className="pb-4">
          <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
            Dataset Size
          </label>
          <div className="flex items-center gap-2">
            <input
              type="number"
              min="1"
              max="600"
              value={params.count}
              onChange={(e) => setParams({ ...params, count: parseInt(e.target.value) || 1 })}
              className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg text-sm text-slate-900 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-colors"
            />
            <span className="text-sm text-slate-500 dark:text-slate-400">imgs</span>
          </div>
        </div>

        {/* --- MODE SWITCHER --- */}
        <div className="bg-slate-100 dark:bg-slate-800 p-1 rounded-lg flex mb-6">
            <button 
                onClick={() => setParams({...params, promptMode: 'builder'})}
                className={`flex-1 flex items-center justify-center gap-2 py-1.5 text-xs font-bold rounded-md transition-all ${params.promptMode === 'builder' ? 'bg-white dark:bg-slate-700 shadow text-indigo-600 dark:text-indigo-400' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
            >
                <Sliders className="w-3 h-3" /> Builder
            </button>
            <button 
                onClick={() => setParams({...params, promptMode: 'raw'})}
                className={`flex-1 flex items-center justify-center gap-2 py-1.5 text-xs font-bold rounded-md transition-all ${params.promptMode === 'raw' ? 'bg-white dark:bg-slate-700 shadow text-indigo-600 dark:text-indigo-400' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
            >
                <Type className="w-3 h-3" /> Prompt
            </button>
        </div>

        {params.promptMode === 'builder' ? (
            <>
                <CollapsibleSection title="Material" defaultOpen={true}>
                <RadioList 
                    options={['asphalt', 'concrete']} 
                    selected={params.material} 
                    onChange={(v) => setParams({ ...params, material: v })} 
                />
                </CollapsibleSection>

                <CollapsibleSection title="Morphology">
                <CheckboxList
                    options={['mapped/alligator', 'single linear cracks', 'main cracks with branching']}
                    selected={params.morphology}
                    onChange={(v) => setParams({ ...params, morphology: v as any })}
                />
                </CollapsibleSection>

                <CollapsibleSection title="Orientation">
                <CheckboxList
                    options={['transverse', 'longitudinal', 'diagonal', 'complex']}
                    selected={params.orientation}
                    onChange={(v) => setParams({ ...params, orientation: v as any })}
                />
                </CollapsibleSection>

                <CollapsibleSection title="Lighting">
                <CheckboxList
                    options={['uniform overhead', 'non-uniform with soft shadows']}
                    selected={params.lighting}
                    onChange={(v) => setParams({ ...params, lighting: v as any })}
                />
                </CollapsibleSection>

                <CollapsibleSection title="Environment">
                <CheckboxList
                    options={['manholes', 'tree leaves', 'pavement edges', 'embankments', 'dirt']}
                    selected={params.environment}
                    onChange={(v) => setParams({ ...params, environment: v as any })}
                />
                </CollapsibleSection>

                <CollapsibleSection title="Surface">
                <CheckboxList
                    options={['smooth', 'rough', 'aggregate pop-outs']}
                    selected={params.texture}
                    onChange={(v) => setParams({ ...params, texture: v as any })}
                />
                </CollapsibleSection>

                <CollapsibleSection title="Other Distresses">
                <CheckboxList
                    options={['potholes', 'patches', 'oil stains']}
                    selected={params.distresses}
                    onChange={(v) => setParams({ ...params, distresses: v as any })}
                />
                </CollapsibleSection>

                <div className="pt-4">
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
                    Custom Details
                </label>
                <textarea 
                    className="w-full text-sm p-2 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg h-20 resize-none text-slate-900 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500 transition-colors"
                    placeholder="E.g. wide angle, wet surface..."
                    value={params.customPrompt}
                    onChange={(e) => setParams({...params, customPrompt: e.target.value})}
                />
                </div>
            </>
        ) : (
            <div className="flex-1 flex flex-col">
                 <div className="bg-indigo-50 dark:bg-indigo-900/20 p-3 rounded-lg mb-4 border border-indigo-100 dark:border-indigo-900/50">
                    <div className="flex gap-2 items-start">
                        <AlertCircle className="w-4 h-4 text-indigo-600 dark:text-indigo-400 mt-0.5 flex-shrink-0" />
                        <p className="text-xs text-indigo-800 dark:text-indigo-300">
                           <strong>Strict Mode:</strong> Your prompt will be validated by AI to ensure it requests a split pavement/mask image. Irrelevant prompts will be rejected.
                        </p>
                    </div>
                 </div>
                 <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
                    Raw Generation Prompt
                </label>
                <textarea 
                    className="w-full flex-1 min-h-[300px] text-sm p-3 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-lg resize-none text-slate-900 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500 transition-colors focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="Describe a top-down pavement crack image on the left and a binary mask on the right..."
                    value={params.rawPrompt}
                    onChange={(e) => setParams({...params, rawPrompt: e.target.value})}
                />
            </div>
        )}

        <CollapsibleSection title="Advanced Settings">
          <div className="space-y-4 pt-2">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  Temperature
                </label>
                <span className="text-xs text-slate-600 dark:text-slate-300">{params.temperature}</span>
              </div>
              <input
                type="range"
                min="0"
                max="2"
                step="0.1"
                value={params.temperature}
                onChange={(e) => setParams({ ...params, temperature: parseFloat(e.target.value) })}
                className="w-full accent-indigo-600"
              />
            </div>
            
            <div>
              <label className="flex items-center text-sm text-slate-700 dark:text-slate-300 hover:text-indigo-900 dark:hover:text-indigo-400 cursor-pointer mb-2">
                <input
                  type="checkbox"
                  checked={params.useRandomSeed}
                  onChange={(e) => setParams({ ...params, useRandomSeed: e.target.checked })}
                  className="w-4 h-4 rounded border-slate-300 dark:border-slate-600 text-indigo-600 focus:ring-indigo-500 bg-white dark:bg-slate-800 mr-2"
                />
                <span>Randomize Seed</span>
              </label>
              
              {!params.useRandomSeed && (
                <div className="flex items-center gap-2">
                  <label className="text-xs text-slate-500 dark:text-slate-400">Seed Value:</label>
                  <input
                    type="number"
                    value={params.seedValue}
                    onChange={(e) => setParams({ ...params, seedValue: parseInt(e.target.value) || 0 })}
                    className="flex-1 px-2 py-1 border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded text-sm text-slate-900 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none transition-colors"
                  />
                </div>
              )}
            </div>
          </div>
        </CollapsibleSection>
      </div>

      <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
        <button
          onClick={isGenerating ? onStop : onGenerate}
          className={`w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-semibold text-white shadow-md transition-all
            ${isGenerating ? 'bg-red-500 hover:bg-red-600' : 'bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98]'}`}
        >
          {isGenerating ? (
            <Square className="w-4 h-4 fill-current" />
          ) : (
            <Play className="w-4 h-4 fill-current" />
          )}
          <span>{isGenerating ? `Stop (${progress})` : 'Generate Dataset'}</span>
        </button>
      </div>
    </div>
  );
};