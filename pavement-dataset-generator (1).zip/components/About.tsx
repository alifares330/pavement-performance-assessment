import React from 'react';
import { GraduationCap, User, UserCheck, University, Mail, Settings2, CheckCircle2, FileJson, Activity } from 'lucide-react';

export const About: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto bg-slate-50 dark:bg-slate-950 p-4 md:p-8 transition-colors">
      <div className="max-w-6xl mx-auto space-y-6 pb-12">
        
        {/* 1. HEADER CARD */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-5 dark:opacity-10 transition-opacity group-hover:opacity-10 dark:group-hover:opacity-20 pointer-events-none">
             <Activity className="w-32 h-32 text-indigo-600" />
          </div>
          <div className="relative z-10">
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Pavement AI Generator</h1>
            <div className="text-sm font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-6">Synthetic Pavement Crack Dataset Generation Tool</div>
            <p className="text-lg text-slate-700 dark:text-slate-300 leading-relaxed max-w-4xl">
              This application is a specialized research tool designed to generate high-fidelity synthetic datasets for pavement crack segmentation. It addresses the scarcity of real-world annotated data by leveraging Google's advanced Generative AI models (Imagen 4 & Gemini) to create perfectly paired RGB pavement images and binary masks on demand.
            </p>
          </div>
        </div>

        {/* 2. GRID ROW: HOW IT WORKS & CAPABILITIES */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* How It Works */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col">
            <div className="flex items-center gap-3 mb-6">
              <Settings2 className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">How It Works</h2>
            </div>
            <div className="prose prose-slate dark:prose-invert text-slate-600 dark:text-slate-400 text-sm leading-relaxed flex-1">
              <p className="mb-4">
                The tool automates the creation of diverse training samples through a controllable generation pipeline. Users can define specific parameters—such as crack morphology, lighting conditions, and surface textures—to simulate a wide range of real-world scenarios that are often difficult to capture manually.
              </p>
              <p>
                By acting as a virtual surveyor, the system synthesizes top-down views that adhere to strict geometric constraints, ensuring that the generated data is immediately usable for training segmentation models without manual labeling.
              </p>
            </div>
          </div>

          {/* Key Capabilities */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col">
            <div className="flex items-center gap-3 mb-6">
              <CheckCircle2 className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Key Capabilities</h2>
            </div>
            <ul className="space-y-4 flex-1">
              {[
                { title: 'Dual-Modality Generation', desc: 'Produces photorealistic pavement images paired with pixel-perfect binary masks.' },
                { title: 'Smart Alignment', desc: 'Post-processing algorithms split, analyze, and align masks with RGB images.' },
                { title: 'Customizable Parameters', desc: 'Control environment (oil, leaves), lighting, and material types.' },
                { title: 'Quality Control', desc: 'Automatically flags samples with issues like empty masks or inverted colors.' }
              ].map((item, i) => (
                <li key={i} className="flex gap-3 items-start">
                  <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-indigo-500 flex-shrink-0" />
                  <div className="text-sm">
                    <strong className="text-slate-900 dark:text-slate-200 block mb-0.5">{item.title}</strong>
                    <span className="text-slate-600 dark:text-slate-400">{item.desc}</span>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* 3. OUTPUT SPECIFICATIONS */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
           <div className="flex items-center gap-3 mb-6">
              <FileJson className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Technical Specifications</h2>
           </div>
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div>
                 <div className="text-xs font-bold text-slate-500 dark:text-slate-500 uppercase tracking-wider mb-1">Output Resolution</div>
                 <div className="font-semibold text-slate-900 dark:text-white">704 × 768 pixels</div>
                 <div className="text-xs text-slate-400 dark:text-slate-500">Per image/mask pair</div>
              </div>
              <div>
                 <div className="text-xs font-bold text-slate-500 dark:text-slate-500 uppercase tracking-wider mb-1">Format</div>
                 <div className="font-semibold text-slate-900 dark:text-white">Paired PNG</div>
                 <div className="text-xs text-slate-400 dark:text-slate-500">RGB + Binary Mask</div>
              </div>
              <div>
                 <div className="text-xs font-bold text-slate-500 dark:text-slate-500 uppercase tracking-wider mb-1">AI Models</div>
                 <div className="font-semibold text-slate-900 dark:text-white">Imagen 4 Ultra</div>
                 <div className="text-xs text-slate-400 dark:text-slate-500">Gemini 3 Pro / 2.5 Flash</div>
              </div>
              <div>
                 <div className="text-xs font-bold text-slate-500 dark:text-slate-500 uppercase tracking-wider mb-1">Viewpoint</div>
                 <div className="font-semibold text-slate-900 dark:text-white">Nadir</div>
                 <div className="text-xs text-slate-400 dark:text-slate-500">Top-down aerial view</div>
              </div>
           </div>
        </div>

        {/* 4. RESEARCH CONTEXT */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
           <h2 className="text-xl font-bold text-indigo-900 dark:text-indigo-400 mb-6">Research Context</h2>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm text-slate-700 dark:text-slate-300">
              <div className="space-y-4">
                  <div className="flex gap-3 items-start">
                    <GraduationCap className="text-indigo-600 dark:text-indigo-400 mt-0.5 w-5 h-5 flex-shrink-0" />
                    <p>
                      Developed as part of doctoral research on multi-sensing pavement performance assessment at <strong className="text-slate-900 dark:text-white">The Hong Kong Polytechnic University</strong>.
                    </p>
                  </div>
                  <div className="flex gap-3 items-start">
                    <User className="text-indigo-600 dark:text-indigo-400 mt-0.5 w-5 h-5 flex-shrink-0" />
                    <p><strong className="text-slate-900 dark:text-white">Researcher:</strong> Ali Fares (PolyU)</p>
                  </div>
              </div>
              <div className="space-y-4">
                  <div className="flex gap-3 items-start">
                    <UserCheck className="text-indigo-600 dark:text-indigo-400 mt-0.5 w-5 h-5 flex-shrink-0" />
                    <p><strong className="text-slate-900 dark:text-white">Supervisor:</strong> Prof. Tarek Zayed (PolyU)</p>
                  </div>
                  <div className="flex gap-3 items-start">
                    <University className="text-indigo-600 dark:text-indigo-400 mt-0.5 w-5 h-5 flex-shrink-0" />
                    <p><strong className="text-slate-900 dark:text-white">Host Supervisor:</strong> Dr. Luis Miranda-Moreno (McGill University)</p>
                  </div>
                  <div className="flex gap-3 items-start">
                    <Mail className="text-indigo-600 dark:text-indigo-400 mt-0.5 w-5 h-5 flex-shrink-0" />
                    <div>
                      <a href="mailto:ali.i.fares@connect.polyu.hk" className="hover:text-indigo-600 dark:hover:text-indigo-400 underline">ali.i.fares@connect.polyu.hk</a>
                    </div>
                  </div>
              </div>
           </div>
        </div>

        {/* 5. LOGO FOOTER */}
        <div className="flex flex-col items-center justify-center pt-8 pb-4">
            <div className="w-32 h-32 bg-white dark:bg-slate-800 rounded-full shadow-lg border-4 border-indigo-100 dark:border-indigo-900/50 flex items-center justify-center mb-4 transition-colors">
              <div className="text-center">
                <div className="text-3xl font-black text-indigo-900 dark:text-indigo-300 tracking-tighter">SiMS</div>
                <div className="text-[10px] font-bold text-indigo-500 dark:text-indigo-400 tracking-widest mt-0.5">LAB</div>
              </div>
            </div>
            <div className="text-center">
              <div className="text-xs font-bold text-indigo-900 dark:text-indigo-300 uppercase tracking-wide">
                Smart Infrastructure & Management Systems
              </div>
            </div>
        </div>

      </div>
    </div>
  );
};
