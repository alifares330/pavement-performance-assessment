import React, { useEffect, useState, useRef, useCallback } from 'react';
import { GeneratedSample, AlignmentTransform } from '../types';
import { processCompositeImage } from '../utils/imageProcessing';
import { applyThreshold, applyMorphology, applyOpening, applyClosing, invertMask, cloneImageData } from '../utils/maskUtils';
import { X, ArrowUp, ArrowDown, ArrowLeft, ArrowRight, RotateCw, RotateCcw, ZoomIn, ZoomOut, Layers, Paintbrush, Eraser, Undo, Redo, Sliders, Trash2, Save, Wand2 } from 'lucide-react';

interface Props {
  sample: GeneratedSample;
  onClose: () => void;
  onUpdate: (id: string, updates: Partial<GeneratedSample>) => void;
}

type EditMode = 'align' | 'edit';
type DrawTool = 'brush' | 'eraser';

export const DetailViewer: React.FC<Props> = ({ sample, onClose, onUpdate }) => {
  // Mode state
  const [mode, setMode] = useState<EditMode>('align');
  
  // Alignment state
  const [transform, setTransform] = useState<AlignmentTransform>(sample.alignment);
  
  // Image Source state
  const [baseImages, setBaseImages] = useState<{pavement: string, mask: string, maskGrayscale: string} | null>(null);
  
  // Editor state
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [drawTool, setDrawTool] = useState<DrawTool>('brush');
  const [brushSize, setBrushSize] = useState(10);
  const [history, setHistory] = useState<ImageData[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [isOverlayMode, setIsOverlayMode] = useState(false);
  const [thresholdRange, setThresholdRange] = useState<[number, number]>([127, 255]);
  const [kernelSize, setKernelSize] = useState(3);

  // --- ALIGNMENT LOGIC ---
  useEffect(() => {
    if (!sample.compositeOriginal) return;
    let active = true;

    const run = async () => {
      const result = await processCompositeImage(sample.compositeOriginal!, transform);
      if (active) {
        setBaseImages(result);
        // If we are in edit mode and re-align, we might lose edits or need to reset.
        // For simplicity, re-alignment resets the editor base.
        // To properly handle this, we reset the canvas when baseImages change.
      }
    };
    run();
    return () => { active = false; };
  }, [sample.compositeOriginal, transform]);

  // --- EDITOR INITIALIZATION ---
  useEffect(() => {
    if (mode === 'edit' && baseImages && canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d', { willReadFrequently: true });
      if (!ctx) return;

      const img = new Image();
      img.onload = () => {
        ctx.clearRect(0, 0, canvasRef.current!.width, canvasRef.current!.height);
        ctx.drawImage(img, 0, 0);
        
        // Initial snapshot for undo stack if empty
        if (history.length === 0) {
            const initialData = ctx.getImageData(0, 0, canvasRef.current!.width, canvasRef.current!.height);
            setHistory([initialData]);
            setHistoryIndex(0);
        }
      };
      // Load the grayscale version for better editing potential (thresholding), 
      // or the binary if we just want to draw. Let's load the binary for consistency with alignment mode,
      // but users can "Reset to Raw" using the grayscale if needed.
      // Actually, for drawing, binary is easier.
      img.src = baseImages.mask;
    }
  }, [mode, baseImages]); // Intentionally not including history to avoid loop

  // --- DRAWING LOGIC ---
  const [isDrawing, setIsDrawing] = useState(false);
  const lastPos = useRef<{x: number, y: number} | null>(null);

  const getPos = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
    
    // Scale for canvas resolution vs display size
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDrawing(true);
    const pos = getPos(e);
    lastPos.current = pos;
    draw(e); // Dot capability
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || !canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;
    
    const pos = getPos(e);
    
    ctx.globalCompositeOperation = drawTool === 'eraser' ? 'destination-out' : 'source-over';
    ctx.strokeStyle = 'white';
    ctx.fillStyle = 'white';
    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    ctx.beginPath();
    if (lastPos.current) {
        ctx.moveTo(lastPos.current.x, lastPos.current.y);
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();
    } else {
        ctx.arc(pos.x, pos.y, brushSize / 2, 0, Math.PI * 2);
        ctx.fill();
    }
    
    lastPos.current = pos;
  };

  const stopDrawing = () => {
    if (!isDrawing) return;
    setIsDrawing(false);
    lastPos.current = null;
    pushToHistory();
  };

  const pushToHistory = () => {
     if (!canvasRef.current) return;
     const ctx = canvasRef.current.getContext('2d', { willReadFrequently: true });
     if (!ctx) return;
     const data = ctx.getImageData(0, 0, canvasRef.current.width, canvasRef.current.height);
     
     const newHistory = history.slice(0, historyIndex + 1);
     newHistory.push(data);
     
     // Limit stack size
     if (newHistory.length > 20) newHistory.shift();
     
     setHistory(newHistory);
     setHistoryIndex(newHistory.length - 1);
  };

  const undo = () => {
    if (historyIndex > 0) {
        const newIndex = historyIndex - 1;
        restoreHistory(newIndex);
        setHistoryIndex(newIndex);
    }
  };

  const redo = () => {
    if (historyIndex < history.length - 1) {
        const newIndex = historyIndex + 1;
        restoreHistory(newIndex);
        setHistoryIndex(newIndex);
    }
  };

  const restoreHistory = (index: number) => {
      if (!canvasRef.current) return;
      const ctx = canvasRef.current.getContext('2d');
      if (!ctx) return;
      ctx.putImageData(history[index], 0, 0);
  };

  // --- FILTER LOGIC ---
  const applyFilter = (op: 'erode'|'dilate'|'open'|'close'|'invert'|'threshold') => {
      if (!canvasRef.current) return;
      const ctx = canvasRef.current.getContext('2d', { willReadFrequently: true });
      if (!ctx) return;
      
      let currentData = ctx.getImageData(0, 0, canvasRef.current.width, canvasRef.current.height);
      let newData: ImageData;

      if (op === 'threshold') {
          // For threshold, we should ideally go back to the grayscale source to be effective,
          // OR we threshold the current canvas if it's already grayscale (it's mostly binary though).
          // Let's reload the grayscale for this op specifically if requested, or just threshold current.
          // The prompt implies a workflow. Let's try thresholding the CURRENT canvas content first.
          newData = applyThreshold(currentData, thresholdRange[0], thresholdRange[1]);
      } else if (op === 'invert') {
          newData = invertMask(currentData);
      } else if (op === 'open') {
          newData = applyOpening(currentData, kernelSize);
      } else if (op === 'close') {
          newData = applyClosing(currentData, kernelSize);
      } else {
          newData = applyMorphology(currentData, op, kernelSize);
      }

      ctx.putImageData(newData, 0, 0);
      pushToHistory();
  };
  
  const resetToGrayscale = () => {
      if (!baseImages?.maskGrayscale || !canvasRef.current) return;
      const ctx = canvasRef.current.getContext('2d');
      if (!ctx) return;
      const img = new Image();
      img.onload = () => {
          ctx.clearRect(0,0, canvasRef.current!.width, canvasRef.current!.height);
          ctx.drawImage(img, 0, 0);
          pushToHistory();
      };
      img.src = baseImages.maskGrayscale;
  }

  // --- SAVE ---
  const handleSave = () => {
    let finalMask = baseImages?.mask; // Default to aligned binary
    
    // If in edit mode, save the canvas content
    if (mode === 'edit' && canvasRef.current) {
        finalMask = canvasRef.current.toDataURL('image/png');
    }

    if (baseImages && finalMask) {
      onUpdate(sample.id, {
        alignment: transform,
        pavementRGB: baseImages.pavement,
        maskBinary: finalMask,
      });
    }
    onClose();
  };

  const updateTransform = (key: keyof AlignmentTransform, delta: number) => {
    setTransform(prev => ({ ...prev, [key]: prev[key] + delta }));
  };
  const setScale = (delta: number) => {
    setTransform(prev => ({ ...prev, scale: Math.max(0.1, prev.scale + delta) }));
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-7xl h-[95vh] flex flex-col overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800 transition-colors">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-900">
          <div className="flex items-center gap-4">
             <div>
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">Sample Inspection: {sample.id}</h2>
                <div className="text-xs text-slate-500 dark:text-slate-400 font-mono mt-1 max-w-lg truncate" title={sample.prompt}>
                {sample.prompt}
                </div>
             </div>
             {/* Mode Switcher */}
             <div className="flex bg-slate-200 dark:bg-slate-800 p-1 rounded-lg">
                <button 
                  onClick={() => setMode('align')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all ${mode === 'align' ? 'bg-white dark:bg-slate-700 shadow text-indigo-600 dark:text-indigo-400' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'}`}
                >
                    Alignment
                </button>
                <button 
                  onClick={() => setMode('edit')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all ${mode === 'edit' ? 'bg-white dark:bg-slate-700 shadow text-indigo-600 dark:text-indigo-400' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'}`}
                >
                    Mask Editor
                </button>
             </div>
          </div>
          
          <div className="flex items-center gap-3">
            <button onClick={handleSave} className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium shadow-md">
              <Save className="w-4 h-4" /> Save Changes
            </button>
            <button onClick={onClose} className="p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full text-slate-500 dark:text-slate-400 transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-100 dark:bg-black/20">
          <div className="grid grid-cols-12 gap-6 h-full min-h-[600px]">
            
            {/* --- LEFT COLUMN: CONTROLS --- */}
            <div className="col-span-4 flex flex-col gap-6">
               
               {mode === 'align' ? (
                   /* Alignment Controls */
                   <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
                        <div className="flex items-center justify-between mb-4">
                            <div>
                                <h4 className="text-sm font-bold text-slate-900 dark:text-white">Geometry</h4>
                                <p className="text-xs text-slate-500 dark:text-slate-400">Global mask transform</p>
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-6">
                            {/* Translation */}
                            <div className="space-y-2">
                                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Position</label>
                                <div className="grid grid-cols-3 gap-1 w-24 mx-auto">
                                    <div />
                                    <button onClick={() => updateTransform('y', -1)} className="p-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded border border-slate-200 dark:border-slate-600 active:bg-indigo-100"><ArrowUp className="w-4 h-4 text-slate-700 dark:text-slate-200"/></button>
                                    <div />
                                    <button onClick={() => updateTransform('x', -1)} className="p-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded border border-slate-200 dark:border-slate-600 active:bg-indigo-100"><ArrowLeft className="w-4 h-4 text-slate-700 dark:text-slate-200"/></button>
                                    <div className="flex items-center justify-center text-[10px] font-mono text-slate-400"><div className="w-1 h-1 bg-slate-400 rounded-full" /></div>
                                    <button onClick={() => updateTransform('x', 1)} className="p-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded border border-slate-200 dark:border-slate-600 active:bg-indigo-100"><ArrowRight className="w-4 h-4 text-slate-700 dark:text-slate-200"/></button>
                                    <div />
                                    <button onClick={() => updateTransform('y', 1)} className="p-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded border border-slate-200 dark:border-slate-600 active:bg-indigo-100"><ArrowDown className="w-4 h-4 text-slate-700 dark:text-slate-200"/></button>
                                    <div />
                                </div>
                                <div className="text-center text-[10px] font-mono text-slate-400 mt-1">X:{transform.x} Y:{transform.y}</div>
                            </div>
                            {/* Scale & Rotate */}
                            <div className="space-y-4">
                                <div className="space-y-2">
                                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Scale</label>
                                    <div className="flex items-center justify-center gap-2">
                                        <button onClick={() => setScale(-0.01)} className="p-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded border border-slate-200 dark:border-slate-600"><ZoomOut className="w-4 h-4 text-slate-700 dark:text-slate-200"/></button>
                                        <span className="text-xs font-mono w-12 text-center text-slate-600 dark:text-slate-300">{transform.scale.toFixed(2)}x</span>
                                        <button onClick={() => setScale(0.01)} className="p-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded border border-slate-200 dark:border-slate-600"><ZoomIn className="w-4 h-4 text-slate-700 dark:text-slate-200"/></button>
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Rotation</label>
                                    <div className="flex items-center justify-center gap-2">
                                        <button onClick={() => updateTransform('rotation', -0.5)} className="p-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded border border-slate-200 dark:border-slate-600"><RotateCcw className="w-4 h-4 text-slate-700 dark:text-slate-200"/></button>
                                        <span className="text-xs font-mono w-12 text-center text-slate-600 dark:text-slate-300">{transform.rotation.toFixed(1)}°</span>
                                        <button onClick={() => updateTransform('rotation', 0.5)} className="p-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded border border-slate-200 dark:border-slate-600"><RotateCw className="w-4 h-4 text-slate-700 dark:text-slate-200"/></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                   </div>
               ) : (
                   /* Edit Mode Controls */
                   <div className="flex flex-col gap-4 h-full">
                       {/* Drawing Tools */}
                       <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
                           <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-3">Drawing</h4>
                           <div className="grid grid-cols-2 gap-2 mb-4">
                               <button onClick={() => setDrawTool('brush')} className={`flex flex-col items-center justify-center p-3 rounded-lg border transition-all ${drawTool === 'brush' ? 'bg-indigo-50 dark:bg-indigo-900/30 border-indigo-200 dark:border-indigo-700 text-indigo-700 dark:text-indigo-400' : 'bg-slate-50 dark:bg-slate-700/50 border-slate-100 dark:border-slate-600 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'}`}>
                                   <Paintbrush className="w-5 h-5 mb-1" />
                                   <span className="text-xs font-medium">Brush</span>
                               </button>
                               <button onClick={() => setDrawTool('eraser')} className={`flex flex-col items-center justify-center p-3 rounded-lg border transition-all ${drawTool === 'eraser' ? 'bg-indigo-50 dark:bg-indigo-900/30 border-indigo-200 dark:border-indigo-700 text-indigo-700 dark:text-indigo-400' : 'bg-slate-50 dark:bg-slate-700/50 border-slate-100 dark:border-slate-600 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'}`}>
                                   <Eraser className="w-5 h-5 mb-1" />
                                   <span className="text-xs font-medium">Eraser</span>
                               </button>
                           </div>
                           <div className="space-y-2">
                               <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400">
                                   <span>Size</span>
                                   <span>{brushSize}px</span>
                               </div>
                               <input type="range" min="1" max="50" value={brushSize} onChange={(e) => setBrushSize(parseInt(e.target.value))} className="w-full h-2 bg-slate-200 dark:bg-slate-600 rounded-lg appearance-none cursor-pointer accent-indigo-600" />
                           </div>
                           <div className="flex gap-2 mt-4 pt-4 border-t border-slate-100 dark:border-slate-700">
                               <button onClick={undo} disabled={historyIndex <= 0} className="flex-1 flex items-center justify-center gap-1 p-2 rounded bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 disabled:opacity-50 text-slate-700 dark:text-slate-300 text-xs font-medium">
                                   <Undo className="w-3 h-3" /> Undo
                               </button>
                               <button onClick={redo} disabled={historyIndex >= history.length - 1} className="flex-1 flex items-center justify-center gap-1 p-2 rounded bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 disabled:opacity-50 text-slate-700 dark:text-slate-300 text-xs font-medium">
                                   <Redo className="w-3 h-3" /> Redo
                               </button>
                           </div>
                       </div>

                       {/* Filters */}
                       <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 flex-1 overflow-y-auto">
                           <div className="flex justify-between items-center mb-3">
                                <h4 className="text-sm font-bold text-slate-900 dark:text-white">Filters</h4>
                                <button onClick={resetToGrayscale} className="text-[10px] text-indigo-600 dark:text-indigo-400 hover:underline">Reset to Raw</button>
                           </div>

                           {/* Kernel Size */}
                           <div className="mb-4 space-y-2">
                               <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400">
                                   <span className="font-semibold text-slate-400 uppercase">Kernel Size</span>
                                   <span>{kernelSize}x{kernelSize}</span>
                               </div>
                               <input 
                                 type="range" 
                                 min="3" 
                                 max="15" 
                                 step="2" 
                                 value={kernelSize} 
                                 onChange={(e) => setKernelSize(parseInt(e.target.value))} 
                                 className="w-full h-2 bg-slate-200 dark:bg-slate-600 rounded-lg appearance-none cursor-pointer accent-indigo-600" 
                               />
                           </div>
                           
                           {/* Threshold */}
                           <div className="mb-6 space-y-2">
                               <label className="text-xs font-semibold text-slate-400 uppercase">Threshold Range</label>
                               <div className="flex gap-2 items-center">
                                   <input type="number" value={thresholdRange[0]} onChange={e => setThresholdRange([+e.target.value, thresholdRange[1]])} className="w-14 text-xs p-1 border rounded bg-white dark:bg-slate-700 border-slate-200 dark:border-slate-600 text-slate-900 dark:text-white" />
                                   <span className="text-slate-400">-</span>
                                   <input type="number" value={thresholdRange[1]} onChange={e => setThresholdRange([thresholdRange[0], +e.target.value])} className="w-14 text-xs p-1 border rounded bg-white dark:bg-slate-700 border-slate-200 dark:border-slate-600 text-slate-900 dark:text-white" />
                                   <button onClick={() => applyFilter('threshold')} className="ml-auto p-1.5 bg-slate-100 dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400" title="Apply Threshold">
                                       <Wand2 className="w-4 h-4" />
                                   </button>
                               </div>
                           </div>

                           {/* Morphology */}
                           <div className="space-y-2">
                               <label className="text-xs font-semibold text-slate-400 uppercase">Morphology</label>
                               <div className="grid grid-cols-2 gap-2">
                                   <button onClick={() => applyFilter('erode')} className="px-3 py-2 bg-slate-50 dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 border border-slate-200 dark:border-slate-600 rounded text-xs font-medium text-slate-700 dark:text-slate-200">Erode</button>
                                   <button onClick={() => applyFilter('dilate')} className="px-3 py-2 bg-slate-50 dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 border border-slate-200 dark:border-slate-600 rounded text-xs font-medium text-slate-700 dark:text-slate-200">Dilate</button>
                                   <button onClick={() => applyFilter('open')} className="px-3 py-2 bg-slate-50 dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 border border-slate-200 dark:border-slate-600 rounded text-xs font-medium text-slate-700 dark:text-slate-200">Open</button>
                                   <button onClick={() => applyFilter('close')} className="px-3 py-2 bg-slate-50 dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 border border-slate-200 dark:border-slate-600 rounded text-xs font-medium text-slate-700 dark:text-slate-200">Close</button>
                               </div>
                               <button onClick={() => applyFilter('invert')} className="w-full mt-2 px-3 py-2 bg-slate-50 dark:bg-slate-700 hover:bg-red-50 dark:hover:bg-red-900/20 border border-slate-200 dark:border-slate-600 rounded text-xs font-medium text-slate-700 dark:text-slate-200 hover:text-red-600 dark:hover:text-red-400">Invert Colors</button>
                           </div>
                       </div>
                   </div>
               )}

               <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 flex-1 flex flex-col min-h-[200px]">
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-2">Original Composite</h4>
                    <div className="bg-black rounded-lg overflow-hidden border border-slate-300 dark:border-slate-600 flex-1 relative">
                        {sample.compositeOriginal ? (
                        <img src={sample.compositeOriginal} className="w-full h-full object-contain absolute inset-0" />
                        ) : (
                        <div className="absolute inset-0 flex items-center justify-center text-white">No data</div>
                        )}
                    </div>
               </div>
            </div>

            {/* --- RIGHT COLUMN: PREVIEW --- */}
            <div className="col-span-8 h-full flex flex-col">
                 <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-slate-900 dark:text-white">
                        {isOverlayMode ? "Overlay Preview (Screen Blend)" : (mode === 'edit' ? "Mask Editor" : "Processed Outputs")}
                    </h3>
                    
                    <button 
                        onClick={() => setIsOverlayMode(!isOverlayMode)}
                        className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors border ${isOverlayMode ? 'bg-indigo-100 text-indigo-700 border-indigo-200 dark:bg-indigo-900 dark:text-indigo-200 dark:border-indigo-700' : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600'}`}
                    >
                        <Layers className="w-3 h-3" />
                        {isOverlayMode ? "Overlay ON" : "Overlay OFF"}
                    </button>
                 </div>

                 <div className="flex-1 bg-black rounded-xl overflow-hidden border border-slate-300 dark:border-slate-600 relative shadow-inner touch-none">
                     {/* 1. Base Pavement Layer (Always visible, z-0) */}
                     {baseImages && (
                         <img 
                            src={baseImages.pavement} 
                            className="w-full h-full object-contain absolute inset-0 z-0 pointer-events-none" 
                         />
                     )}

                     {/* 2. Mask Layer (Can be Canvas or Image) */}
                     <div className={`absolute inset-0 z-10 w-full h-full ${isOverlayMode ? 'mix-blend-screen opacity-80' : ''}`}>
                        {mode === 'edit' ? (
                            <canvas 
                                ref={canvasRef}
                                width={704}
                                height={768}
                                className="w-full h-full object-contain cursor-crosshair"
                                onMouseDown={startDrawing}
                                onMouseMove={draw}
                                onMouseUp={stopDrawing}
                                onMouseLeave={stopDrawing}
                                onTouchStart={startDrawing}
                                onTouchMove={draw}
                                onTouchEnd={stopDrawing}
                            />
                        ) : (
                            baseImages && (
                                <img 
                                    src={baseImages.mask} 
                                    className="w-full h-full object-contain pointer-events-none" 
                                />
                            )
                        )}
                     </div>

                     {/* Overlay Indicator */}
                     {isOverlayMode && (
                        <div className="absolute bottom-4 right-4 z-30 bg-black/50 text-white text-xs px-2 py-1 rounded backdrop-blur-md pointer-events-none">
                            Overlay View
                        </div>
                     )}
                 </div>
                 
                 {/* Footer Info */}
                 <div className="mt-2 flex justify-between text-xs text-slate-400 dark:text-slate-500 px-1">
                     <span>704 x 768 px</span>
                     <span>{mode === 'edit' ? `${historyIndex + 1}/${history.length} states` : 'Alignment Mode'}</span>
                 </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};