import path from 'path';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
    return {
      plugins: [react()],
      server: {
        port: 3000,
        host: '0.0.0.0',
      },
      resolve: {
        alias: {
          // Points '@' to the project root directory so we can import files easily
          "@": path.resolve("./"),
        },
      },
    };
});