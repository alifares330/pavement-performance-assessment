export type CrackMorphology = 'mapped/alligator' | 'single linear cracks' | 'main cracks with branching';
export type CrackOrientation = 'transverse' | 'longitudinal' | 'diagonal' | 'complex';
export type LightingCondition = 'uniform overhead' | 'non-uniform with soft shadows';
export type EnvironmentFeature = 'manholes' | 'tree leaves' | 'pavement edges' | 'embankments' | 'dirt';
export type SurfaceTexture = 'smooth' | 'rough' | 'aggregate pop-outs';
export type OtherDistress = 'potholes' | 'patches' | 'oil stains';
export type PavementMaterial = 'asphalt' | 'concrete';
export type AIModel = 'imagen-4' | 'gemini-flash' | 'gemini-pro-image';

export interface GenerationParams {
  count: number;
  model: AIModel;
  material: PavementMaterial;
  morphology: CrackMorphology[];
  orientation: CrackOrientation[];
  lighting: LightingCondition[];
  environment: EnvironmentFeature[];
  texture: SurfaceTexture[];
  distresses: OtherDistress[];
  customPrompt: string;
  promptMode: 'builder' | 'raw';
  rawPrompt: string;
  temperature: number;
  useRandomSeed: boolean;
  seedValue: number;
}

export interface AlignmentTransform {
  x: number;
  y: number;
  scale: number;
  rotation: number;
}

export interface TokenUsage {
  promptTokens: number;
  responseTokens: number;
  totalTokens: number;
}

export interface GeneratedSample {
  id: string;
  timestamp: number;
  status: 'pending' | 'processing' | 'complete' | 'error';
  params: Record<string, string>; // The specific random params selected for this sample
  prompt: string;
  
  // Images (Data URLs)
  compositeOriginal?: string;
  pavementRGB?: string;
  maskBinary?: string;

  // Metadata
  alignment: AlignmentTransform;
  qcFlags: string[];
  executionTimeMs?: number;
  tokenUsage?: TokenUsage;
}