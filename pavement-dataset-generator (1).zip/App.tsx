import React, { useState, useRef, useEffect } from 'react';
import { ControlPanel } from './components/ControlPanel';
import { DetailViewer } from './components/DetailViewer';
import { About } from './components/About';
import { ApiKeyModal } from './components/ApiKeyModal';
import { GenerationParams, GeneratedSample } from './types';
import { generateSample, validatePavementPrompt } from './services/genAiService';
import { processCompositeImage } from './utils/imageProcessing';
import { Download, AlertCircle, Search, CheckCircle2, LayoutGrid, Info, Sun, Moon, Key, Loader2, Zap } from 'lucide-react';
// @ts-ignore
import JSZip from 'jszip';

type ViewMode = 'gallery' | 'about';

const App: React.FC = () => {
  const [view, setView] = useState<ViewMode>('gallery');
  const [darkMode, setDarkMode] = useState(false);
  
  // API Key State - Initialize synchronously to guarantee UI state on first render
  const [apiKey, setApiKey] = useState<string>(() => localStorage.getItem('gemini_api_key') || '');
  const [isKeyModalOpen, setIsKeyModalOpen] = useState(() => !localStorage.getItem('gemini_api_key'));

  const handleSaveKey = (key: string) => {
      localStorage.setItem('gemini_api_key', key);
      setApiKey(key);
      setIsKeyModalOpen(false);
  };
  
  const [params, setParams] = useState<GenerationParams>({
    count: 5,
    model: 'imagen-4',
    material: 'asphalt',
    morphology: ['single linear cracks'],
    orientation: ['transverse', 'diagonal'],
    lighting: ['uniform overhead'],
    environment: ['tree leaves'],
    texture: ['rough'],
    distresses: ['potholes'],
    customPrompt: '',
    promptMode: 'builder',
    rawPrompt: '',
    temperature: 0.1,
    useRandomSeed: false,
    seedValue: 42
  });

  const [samples, setSamples] = useState<GeneratedSample[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [progressText, setProgressText] = useState("");
  const [selectedSampleId, setSelectedSampleId] = useState<string | null>(null);
  
  // Ref to track if generation should be aborted
  const abortRef = useRef(false);

  // Effect to apply dark mode class
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const handleGenerate = async () => {
    if (!apiKey) {
        setIsKeyModalOpen(true);
        return;
    }

    // Force switch to gallery when generating
    if (view !== 'gallery') setView('gallery');

    setIsGenerating(true);
    abortRef.current = false; // Reset abort signal

    // --- PROMPT VALIDATION (RAW MODE ONLY) ---
    if (params.promptMode === 'raw') {
        setProgressText("Validating Prompt...");
        try {
            if (!params.rawPrompt.trim()) throw new Error("Prompt cannot be empty");
            const validation = await validatePavementPrompt(params.rawPrompt, apiKey);
            if (!validation.valid) {
                alert(`Prompt Rejected: ${validation.message}`);
                setIsGenerating(false);
                setProgressText("");
                return;
            }
        } catch (e: any) {
            console.error(e);
            alert(`Validation Error: ${e.message}`);
            setIsGenerating(false);
            setProgressText("");
            return;
        }
    }

    let successCount = 0;

    for (let i = 0; i < params.count; i++) {
      // Check for stop signal at start of iteration
      if (abortRef.current) {
        break;
      }

      setProgressText(`${i + 1} / ${params.count}`);
      
      const newSample: GeneratedSample = {
        id: `sample_${Date.now()}_${i}`,
        timestamp: Date.now(),
        status: 'pending',
        params: {},
        prompt: '',
        alignment: { x: 0, y: 0, scale: 1.0, rotation: 0 },
        qcFlags: []
      };

      // Add to list immediately as pending
      setSamples(prev => [newSample, ...prev]);

      try {
        // 1. Generate (pass API KEY)
        const genResult = await generateSample(params, apiKey);
        
        // 2. Process
        const procResult = await processCompositeImage(genResult.image, newSample.alignment);

        // 3. Update Sample
        setSamples(prev => prev.map(s => s.id === newSample.id ? {
          ...s,
          status: 'complete',
          compositeOriginal: genResult.image,
          pavementRGB: procResult.pavement,
          maskBinary: procResult.mask,
          qcFlags: procResult.flags,
          prompt: genResult.prompt,
          params: genResult.usedParams,
          executionTimeMs: genResult.executionTimeMs,
          tokenUsage: genResult.tokenUsage
        } : s));
        successCount++;

      } catch (error) {
        console.error(error);
        setSamples(prev => prev.map(s => s.id === newSample.id ? { ...s, status: 'error' } : s));
        
        // If 401/403 or API key issue, might want to alert
        if (error instanceof Error && (error.message.includes('API Key') || error.message.includes('403'))) {
            setIsKeyModalOpen(true);
            abortRef.current = true; // Stop loop
        }
      }
      
      // Small delay to prevent rate limits
      await new Promise(r => setTimeout(r, 1000));
    }

    setIsGenerating(false);
    setProgressText("");
  };

  const handleStop = () => {
    abortRef.current = true;
  };

  const handleUpdateSample = (id: string, updates: Partial<GeneratedSample>) => {
    setSamples(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
  };

  const handleDownloadAll = async () => {
    const zip = new JSZip();
    const completed = samples.filter(s => s.status === 'complete');
    
    // 1. Add CSV Metadata
    let csvContent = "id,timestamp,prompt,model,material,morphology,orientation,lighting,texture,environment,distresses,execution_time_ms,total_tokens,offset_x,offset_y,scale,rotation,flags\n";
    completed.forEach(s => {
      const p = s.params || {};
      const row = [
        s.id,
        new Date(s.timestamp).toISOString(),
        `"${s.prompt.replace(/"/g, '""')}"`,
        p.model,
        p.material,
        p.morphology,
        p.orientation,
        p.lighting,
        p.texture,
        `"${p.environment}"`,
        `"${p.distresses}"`,
        s.executionTimeMs || '',
        s.tokenUsage?.totalTokens || '',
        s.alignment.x,
        s.alignment.y,
        s.alignment.scale,
        s.alignment.rotation,
        s.qcFlags.join(';')
      ].join(",");
      csvContent += row + "\n";
    });
    zip.file("metadata.csv", csvContent);

    // 2. Add Images
    const imgFolder = zip.folder("images");
    const maskFolder = zip.folder("masks");
    const compFolder = zip.folder("composites");

    completed.forEach(s => {
      if (s.pavementRGB) imgFolder.file(`${s.id}.png`, s.pavementRGB.split(',')[1], {base64: true});
      if (s.maskBinary) maskFolder.file(`${s.id}_mask.png`, s.maskBinary.split(',')[1], {base64: true});
      if (s.compositeOriginal) compFolder.file(`${s.id}_composite.png`, s.compositeOriginal.split(',')[1], {base64: true});
    });

    // 3. Generate Zip
    const content = await zip.generateAsync({type:"blob"});
    const url = URL.createObjectURL(content);
    const link = document.createElement('a');
    link.href = url;
    link.download = "pavement_dataset.zip";
    link.click();
  };

  const selectedSample = samples.find(s => s.id === selectedSampleId);

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-950 overflow-hidden transition-colors duration-200">
      <ApiKeyModal 
        isOpen={isKeyModalOpen} 
        onSave={handleSaveKey} 
        onClose={() => setIsKeyModalOpen(false)} 
        initialKey={apiKey}
        forced={!apiKey}
      />

      <ControlPanel 
        params={params} 
        setParams={setParams} 
        onGenerate={handleGenerate} 
        onStop={handleStop}
        isGenerating={isGenerating}
        progress={progressText}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 flex items-center justify-between shadow-sm z-10 transition-colors duration-200">
          <div className="flex items-center gap-6 h-full">
             {/* Tab Switcher */}
             <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg transition-colors">
                <button 
                  onClick={() => setView('gallery')}
                  className={`flex items-center gap-2 px-4 py-1.5 text-sm font-semibold rounded-md transition-all ${view === 'gallery' ? 'bg-white dark:bg-slate-700 shadow text-slate-900 dark:text-white' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300'}`}
                >
                   <LayoutGrid className="w-4 h-4" /> Gallery
                   <span className="bg-slate-200 dark:bg-slate-600 text-slate-600 dark:text-slate-200 text-[10px] px-1.5 py-0.5 rounded-full ml-1">{samples.length}</span>
                </button>
                <button 
                  onClick={() => setView('about')}
                  className={`flex items-center gap-2 px-4 py-1.5 text-sm font-semibold rounded-md transition-all ${view === 'about' ? 'bg-white dark:bg-slate-700 shadow text-slate-900 dark:text-white' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300'}`}
                >
                   <Info className="w-4 h-4" /> About Project
                </button>
             </div>
          </div>
          
          <div className="flex gap-3 items-center">
             <button
                onClick={() => setIsKeyModalOpen(true)}
                className={`p-2 rounded-lg transition-colors ${!apiKey ? 'bg-red-100 text-red-600 animate-pulse' : 'text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-200'}`}
                title="Manage API Key"
             >
                <Key className="w-5 h-5" />
             </button>

             <button
                onClick={() => setDarkMode(!darkMode)}
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-200 transition-colors"
                title="Toggle Dark Mode"
             >
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
             </button>

             <button 
                onClick={handleDownloadAll}
                disabled={samples.filter(s => s.status === 'complete').length === 0}
                className="flex items-center gap-2 px-4 py-2 bg-slate-900 dark:bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-slate-800 dark:hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
             >
               <Download className="w-4 h-4" /> Download ZIP
             </button>
          </div>
        </header>

        {view === 'gallery' ? (
          <main className="flex-1 overflow-y-auto p-8">
            {samples.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-600">
                <Search className="w-16 h-16 mb-4 opacity-20" />
                <p className="text-lg font-medium">No samples generated yet</p>
                <p className="text-sm">Configure parameters and click Generate to start</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pb-20">
                {samples.map(sample => (
                  <div 
                    key={sample.id} 
                    onClick={() => sample.status === 'complete' && setSelectedSampleId(sample.id)}
                    className={`group relative bg-white dark:bg-slate-800 rounded-xl overflow-hidden border transition-all hover:shadow-lg cursor-pointer
                      ${sample.status === 'error' ? 'border-red-200 dark:border-red-900/50' : 'border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-500'}`}
                  >
                    <div className="aspect-[16/9] bg-slate-100 dark:bg-slate-900 relative">
                      {sample.compositeOriginal ? (
                        <img src={sample.compositeOriginal} className="w-full h-full object-cover" />
                      ) : (
                        <div className="absolute inset-0 flex items-center justify-center">
                          {sample.status === 'pending' && <div className="w-6 h-6 border-2 border-slate-300 dark:border-slate-600 rounded-full" />}
                          {sample.status === 'error' && <AlertCircle className="w-8 h-8 text-red-400" />}
                        </div>
                      )}
                      
                      {/* Status Overlay */}
                      <div className="absolute top-2 right-2 flex gap-1">
                        {sample.qcFlags.length > 0 && (
                          <div className="bg-amber-500 text-white p-1 rounded-full shadow-sm" title="QC Flagged">
                            <AlertCircle className="w-3 h-3" />
                          </div>
                        )}
                        {sample.status === 'complete' && (
                           <div className="bg-green-500 text-white p-1 rounded-full shadow-sm">
                             <CheckCircle2 className="w-3 h-3" />
                           </div>
                        )}
                      </div>
                    </div>

                    <div className="p-3">
                       <div className="flex justify-between items-start mb-1">
                          <div className="text-xs font-mono text-slate-400 dark:text-slate-500 truncate w-24">{sample.id.split('_').pop()}</div>
                          <div className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase px-1.5 py-0.5 bg-slate-100 dark:bg-slate-700 rounded">
                            {sample.params?.morphology || (sample.params?.mode === 'raw' ? 'Custom' : 'Pending...')}
                          </div>
                       </div>
                       
                       <div className="flex items-center justify-between gap-2">
                           <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 h-8 leading-relaxed flex-1">
                             {sample.prompt || "Waiting for generation..."}
                           </p>
                           {sample.status === 'complete' && (
                               <div className="group/metric relative flex-shrink-0">
                                   <Zap className="w-3.5 h-3.5 text-slate-400 hover:text-amber-500 cursor-help" />
                                   {/* Tooltip */}
                                   <div className="absolute bottom-full right-0 mb-2 w-max px-2 py-1.5 bg-slate-800 text-white text-[10px] rounded shadow-xl opacity-0 group-hover/metric:opacity-100 transition-opacity pointer-events-none z-20 border border-slate-700">
                                       <div className="font-semibold mb-0.5 border-b border-slate-700 pb-0.5 text-slate-300">Generation Metrics</div>
                                       {sample.params?.model && (
                                           <div className="text-slate-500 mb-0.5 border-b border-slate-700/50 pb-0.5 capitalize">{sample.params.model}</div>
                                       )}
                                       <div>Time: <span className="text-amber-400">{sample.executionTimeMs ? (sample.executionTimeMs / 1000).toFixed(2) : '0.00'}s</span></div>
                                       
                                       {sample.params?.model === 'imagen-4' ? (
                                            <div>Quota: <span className="text-indigo-400">1 Image</span></div>
                                       ) : sample.tokenUsage ? (
                                           <div>Tokens: <span className="text-indigo-400">{sample.tokenUsage.totalTokens}</span></div>
                                       ) : (
                                            <div className="text-slate-500 italic">Tokens: Unavailable</div>
                                       )}
                                   </div>
                               </div>
                           )}
                       </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </main>
        ) : (
          <About />
        )}
      </div>

      {selectedSample && (
        <DetailViewer 
          sample={selectedSample} 
          onClose={() => setSelectedSampleId(null)}
          onUpdate={handleUpdateSample}
        />
      )}
    </div>
  );
};

export default App;